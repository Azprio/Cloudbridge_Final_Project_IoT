<?php

require './classes/super_admin.php';
$ob_sup_admin = new Super_admin();
$gpio=4;
$query_result=$ob_sup_admin->gpio_switch_input_status_status($gpio);
$sw_info=mysqli_fetch_assoc($query_result);


if($sw_info['switch_status']==1){
$ob_sup_admin->update_switch_off_status($gpio);
system("gpio -g mode $gpio out");
system("gpio -g write $gpio 0");
}  else {
    $ob_sup_admin->update_switch_on_status($gpio);
    system("gpio -g mode $gpio out");
    system("gpio -g write $gpio 1");
}
?>